+++
title = "{{ replace .TranslationBaseName "-" " " | title }}"
date =  {{ .Date }}
weight = 5
+++

Lorem Ipsum.