// +build mage,!windows

package main

func NonWindowsTarget() {}
