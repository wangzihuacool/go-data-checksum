// +build mage

package main

// RepeatingSynopsis chops off the repeating function name.
// Some more text.
func RepeatingSynopsis() error {
	return nil
}
