//+build mage

package pkg

// Build builds stuff.
func Build() {
}
